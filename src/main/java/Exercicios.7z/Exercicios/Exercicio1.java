/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicios;
import java.util.Scanner;
/**
 *
 * @author elvis.emandrade
 */
public class Exercicio1 {
   
    
    public static void main (String[]args){
    
    Scanner sc = new Scanner(System.in);    
    
    float n1, n2, resultado;
    System.out.println("Resultado");
    
    System.out.println("Digite o 1º número: ");
     n1 = sc.nextFloat();
     System.out.println("Digite o 2º número: ");
     n2 = sc.nextFloat();
    resultado = n1 * n2;
    
    System.out.println("O resultado é " + resultado);
    }
}
